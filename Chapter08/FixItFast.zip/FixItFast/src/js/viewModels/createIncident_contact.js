/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
'use strict';
define(['ojs/ojradioset'], function(oj) {
  function createIncidentContactViewModel() {
    // You can load customer data in this view model
  }

  return createIncidentContactViewModel;

});
